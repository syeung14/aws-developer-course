from decimal import Decimal
import json
import argparse
import boto3
from pprint import pprint, pformat
import time
import random
import threading


def load_dataset(infile, targettable):

    region=boto3.session.Session().region_name
    dynamodb = boto3.resource('dynamodb', region_name=region) # low-level client
    table = dynamodb.Table(targettable)

    with open(infile,"r") as json_file:
            data_list = json.load(json_file, parse_float=Decimal)
            with table.batch_writer() as batch:
                for i in range(len(data_list)):
                    batch.put_item(Item=data_list[i])
    json_file.close()
    #for dataitem in dataset:
    #    response = table.put_item(Item=dataitem)

if __name__ == '__main__':
#    parser = argparse.ArgumentParser()
#    parser.add_argument("tablename", help="name of the dynamodb table to target")
#    parser.add_argument("datafile", help="location of text data file, ex: movies.json")
#    args = parser.parse_args()

    start = time.time()

    t1 = threading.Thread(target=load_dataset, args=('orders1.json', 'orders',))
    t2 = threading.Thread(target=load_dataset, args=('orders2.json', 'orders',))
    t3 = threading.Thread(target=load_dataset, args=('orders3.json', 'orders',))
    t4 = threading.Thread(target=load_dataset, args=('orders4.json', 'orders',))
    t5 = threading.Thread(target=load_dataset, args=('orders5.json', 'orders',))

    t1.start()
    print('Loading the data... this may take a minute or two...')
    time.sleep(2)
    t2.start()
    time.sleep(2)
    t3.start()
    time.sleep(2)
    t4.start()
    time.sleep(2)
    t5.start()

    t1.join()
    t2.join()
    t3.join()
    t4.join()
    t5.join()
    
    end = time.time()
    print('Data successfully loaded')
    print('Total time: {} sec'.format(end - start))
