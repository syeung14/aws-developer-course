from pprint import pprint
import boto3
from boto3.dynamodb.conditions import Key, Attr
import argparse
import time
from decimal import *

def MakeGSI():
    region=boto3.session.Session().region_name
    dynamodb = boto3.resource('dynamodb', region_name=region) #low-level Client
    table = dynamodb.Table('orders') #define which dynamodb table to access

    response = table.update(
        AttributeDefinitions=[
            {
                "AttributeName": "eventSku",
                "AttributeType": "S"
            },
            {
                "AttributeName": "orderStatus",
                "AttributeType": "S"
            },
        ],
        GlobalSecondaryIndexUpdates=[
            {
                'Create': {
                    'IndexName': "event-globo-index",
                    'KeySchema': [
                        {
                            'AttributeName': "eventSku",
                            'KeyType': 'HASH'
                        },
                        {
                            'AttributeName': "orderStatus",
                            'KeyType': 'RANGE'
                        }
                    ],
                    'Projection': {
                        'ProjectionType': 'INCLUDE',
                        'NonKeyAttributes': [
                            'custId',
                            'orderId',
                            'prodSku',
                            'orderQty'
                        ]

                    }
                }
            }
        ],
    )

    table.reload()       # this section to reload the table status every 10 seconds until the GSI finishes creating
    tmpreply = table.global_secondary_indexes
    indexnum = 0;
    while tmpreply[indexnum]['IndexName'] != "event-globo-index" :   # in case other indexes exist for this table, find the one we just created
        indexnum += 1
    while tmpreply[indexnum]['IndexStatus'] != 'ACTIVE':    # check to see if the new one is active yet, and if not... repeat until it is
        time.sleep(10)
        print("Still creating...")
        table.reload()
        tmpreply = table.global_secondary_indexes

    return response

if __name__ == '__main__':

    start = time.time()
    result = MakeGSI()
    end = time.time()
    print('Total time: {} sec'.format(end - start))
