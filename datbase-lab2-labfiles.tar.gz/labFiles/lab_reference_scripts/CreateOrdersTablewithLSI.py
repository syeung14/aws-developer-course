import boto3
import time

def create_orders_table():
  region=boto3.session.Session().region_name
  dynamodb = boto3.resource('dynamodb', region_name=region) #low-level client
  table = dynamodb.create_table(
    TableName='orders',
    BillingMode='PAY_PER_REQUEST',
    KeySchema=[
        {
            'AttributeName': 'custId',
            'KeyType': 'HASH' #Partition Key
        },
        {
            'AttributeName': 'orderId',
            'KeyType': 'RANGE'  #Sort Key
        }
    ],
    AttributeDefinitions=[
        {
            'AttributeName': 'custId',
            'AttributeType': 'S'
        },
        {
            'AttributeName': 'orderId',
            'AttributeType': 'N'
        },
        {
            'AttributeName': 'orderTs',
            'AttributeType': 'N'
        },
    ],
    LocalSecondaryIndexes=[
        {
            'IndexName': 'timestamp-index',
            'KeySchema': [
                {
                    'AttributeName': 'custId',
                    'KeyType': 'HASH'
                },
                {
                    'AttributeName': 'orderTs',
                    'KeyType': 'RANGE'
                },
            ],
            'Projection': {
                'ProjectionType': 'ALL',
            }
        }
    ]
#    ProvisionedThroughput={
#        'ReadCapacityUnits': 0,
#        'WriteCapacityUnits': 0
#    }
  )
  return table

if __name__ == '__main__':
    movie_table = create_orders_table()
    print("Table status:", movie_table.table_status)
    time.sleep(15)
