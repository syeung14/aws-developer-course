from pprint import pprint
import boto3
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError
import argparse
import time
from decimal import *
import random
import threading
import json

def load_dataset(infile, targettable):

    region=boto3.session.Session().region_name
    dynamodb = boto3.resource('dynamodb', region_name=region) # low-level client
    table = dynamodb.Table(targettable)

    with open(infile,"r") as json_file:
            data_list = json.load(json_file, parse_float=Decimal)
            with table.batch_writer() as batch:
                for i in range(len(data_list)):
                    try:
                        batch.put_item(Item=data_list[i])
                    except ClientError as e:
                        print(e.response['Error']['Message'])
                        print('Unable to completely load data due to improper table creation.  Review your key choices.')
                        quit()

def check_table_load(InputTable):
    region=boto3.session.Session().region_name
    dynamodb = boto3.resource('dynamodb', region_name=region) #low-level Client
    table = dynamodb.Table(InputTable) #define which dynamodb table to access

    recordcount = 0
    recordscannedcount = 0
    capacitycount = 0

    try:
        scanreturn = table.scan()                    # perform first scan
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        recordcount += scanreturn['Count']
        while 'LastEvaluatedKey' in scanreturn.keys(): # if lastevaluatedkey is present, we need to keep scanning and adding to our counts until everything is scanned
            try:
                scanreturn = table.scan(
                    ExclusiveStartKey = scanreturn['LastEvaluatedKey']
                )
            except ClientError as e:
                print(e.response['Error']['Message'])
            else:
                recordcount += scanreturn['Count']
        return recordcount  # return the count of items returned by the scan


def verify_orders_table(InputTable):
    region=boto3.session.Session().region_name
    dynamodb = boto3.client('dynamodb', region_name=region) #low-level Client

    try:
        response = dynamodb.describe_table(TableName=InputTable)
    except ClientError as e:
        print(e.response['Error']['Message'])
        print('Unable to get details for a dynamodb table named ' + InputTable +'.  Does the table exist?')
        quit()
    else:
        if 'custId' in str(response['Table']['KeySchema']):
            cuskey = True
        else:
            cuskey = False
            print('The \"custId\" attribute is not a key of the base orders table.')
            print('This is not the ideal architecture.  You may see errors while loading data.')
            print('-----------------------------------')
        if 'orderId' in str(response['Table']['KeySchema']):
            orderkey = True
        else:
            orderkey = False
            print('The \"orderId\" attribute is not a key of the base orders table.')
            print('This is not the ideal architecture.  You may see errors while loading data.')
            print('-----------------------------------')
        if cuskey and orderkey:
            basekey = True
        else:
            basekey = False
        if 'LocalSecondaryIndexes' in response['Table']:
            if 'orderTs' not in str(response['Table']['LocalSecondaryIndexes'][0]['KeySchema']):
                #print('Local index does not use \"orderTs\" timestamp attribute as a key.')
                #print('This is not the ideal LSI architecture.')
                #print('-----------------------------------')
                LSIname = 'Nope'
            else:
                LSIname = response['Table']['LocalSecondaryIndexes'][0]['IndexName']
        else:
            #print('No local secondary index was found.')
            #print('This is not the ideal architecture.')
            #print('-----------------------------------')
            LSIname = 'Nope'
        if 'GlobalSecondaryIndexes' in response['Table']:
            if ('eventSku' not in str(response['Table']['GlobalSecondaryIndexes'][0]['KeySchema'])) or ('orderStatus' not in str(response['Table']['GlobalSecondaryIndexes'][0]['KeySchema'])):
                #print('Global index does not use both \"eventSku\" and \"orderStatus\" as keys.')
                #print('This is not the ideal GSI architecture.')
                #print('-----------------------------------')
                GSIname = 'Nope'
            else:
                GSIname = response['Table']['GlobalSecondaryIndexes'][0]['IndexName']
        else:
            #print('No Global secondary index was found.')
            #print('This is not the ideal architecture.')
            #print('-----------------------------------')
            GSIname = 'Nope'
        return basekey, LSIname, GSIname


def add_order(InputTable):
    region=boto3.session.Session().region_name
    dynamodb = boto3.resource('dynamodb', region_name=region) #low-level Client
    table = dynamodb.Table(InputTable) #define which dynamodb table to access

    try:
        response = table.put_item(
        Item={ 'custId': 'LL4H5L', 'orderId': 98765, 'orderQty': 13, 'salePrice': Decimal('13.99'), 'orderTs': Decimal(str(time.time())), 'costPrice': Decimal('12.5'), 'orderStatus': 'open', 'prodSku':'045GK48BP5', 'eventSku':'RXD5' }
        )
    except ClientError as e:
        print(e.response['Error']['Message'])


def scan_order(InputTable):
    region=boto3.session.Session().region_name
    dynamodb = boto3.resource('dynamodb', region_name=region) #low-level Client
    table = dynamodb.Table(InputTable) #define which dynamodb table to access

    recordcount = 0
    recordscannedcount = 0
    capacitycount = 0

    try:
        scanreturn = table.scan(                    # perform first scan
            FilterExpression=Attr("custId").eq('LL4H5L') & Attr("orderId").eq(98765),
            ReturnConsumedCapacity='TOTAL'
        )
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        recordcount += scanreturn['Count']
        recordscannedcount += scanreturn['ScannedCount']
        capacitycount += scanreturn['ConsumedCapacity']['CapacityUnits']
        while 'LastEvaluatedKey' in scanreturn.keys(): # if lastevaluatedkey is present, we need to keep scanning and adding to our counts until everything is scanned
            try:
                scanreturn = table.scan(
                    FilterExpression=Attr("custId").eq('LL4H5L') & Attr("orderId").eq(98765),
                    ExclusiveStartKey = scanreturn['LastEvaluatedKey'],
                    ReturnConsumedCapacity='TOTAL'
                )
            except ClientError as e:
                print(e.response['Error']['Message'])
            else:
                recordcount += scanreturn['Count']
                recordscannedcount += scanreturn['ScannedCount']
                capacitycount += scanreturn['ConsumedCapacity']['CapacityUnits']
        print("Count is ", recordcount)  # print the count of items returned by the scan
        print("ScannedCount is ", recordscannedcount)  # print the count of items that had to be scanned to process the scan
        print("ConsumedCapacity is", capacitycount)



def get_order(InputTable):
    region=boto3.session.Session().region_name
    dynamodb = boto3.resource('dynamodb', region_name=region) #low-level Client
    table = dynamodb.Table(InputTable) #define which dynamodb table to access

    try:
        response = table.get_item(Key={'custId':'LL4H5L', 'orderId':98765}, ReturnConsumedCapacity='TOTAL')
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        print("Count is 1")  # print the count of items returned by the query
        print("ScannedCount is 1")  # print the count of items that had to be scanned to process the query
        print("ConsumedCapacity is", response['ConsumedCapacity']['CapacityUnits'])


def scan_orders_recent_ten(custID, InputTable):
    region=boto3.session.Session().region_name
    dynamodb = boto3.resource('dynamodb', region_name=region) #low-level Client
    table = dynamodb.Table(InputTable) #define which dynamodb table to access

    recordcount = 0
    recordscannedcount = 0
    capacitycount = 0

    try:
        scanreturn = table.scan(                    # perform first scan
            FilterExpression=Attr("custId").eq(custID),
            ReturnConsumedCapacity='TOTAL'
        )
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        recordcount += scanreturn['Count']
        recordscannedcount += scanreturn['ScannedCount']
        capacitycount += scanreturn['ConsumedCapacity']['CapacityUnits']
        while 'LastEvaluatedKey' in scanreturn.keys(): # if lastevaluatedkey is present, we need to keep scanning and adding to our counts until everything is scanned
            try:
                scanreturn = table.scan(
                    FilterExpression=Attr("custId").eq(custID),
                    ExclusiveStartKey = scanreturn['LastEvaluatedKey'],
                    ReturnConsumedCapacity='TOTAL'
                )
            except ClientError as e:
                print(e.response['Error']['Message'])
            else:
                recordcount += scanreturn['Count']
                recordscannedcount += scanreturn['ScannedCount']
                capacitycount += scanreturn['ConsumedCapacity']['CapacityUnits']
        print("Count is ", recordcount, ' Note: Scans can only go \"forwards\", so using scan and filter to get most recent 10 would require getting all records and then using')
        print('logic to return only the most recent 10')  # print the count of items returned by the scan
        print("ScannedCount is ", recordscannedcount)  # print the count of items that had to be scanned to process the scan
        print("ConsumedCapacity is", capacitycount)


def query_orders_recent_ten_LSI(custID, LI_name, InputTable):
    region=boto3.session.Session().region_name
    dynamodb = boto3.resource('dynamodb', region_name=region) #low-level Client
    table = dynamodb.Table(InputTable) #define which dynamodb table to access

    try:
        queryreturn = table.query(                    # perform first scan
            IndexName=LI_name,
            Limit = 10,
            KeyConditionExpression=Key("custId").eq(custID),
            ScanIndexForward=False,
            ReturnConsumedCapacity='TOTAL'
        )
    except ClientError as e:
        print('Error:  Cannot conduct a query for the customer ', custID)
        print(e.response['Error']['Message'])
    else:
        print("Count is ", queryreturn['Count'])  # print the count of items returned by the query
        print("ScannedCount is ", queryreturn['ScannedCount'])  # print the count of items that had to be scanned to process the query
        print("ConsumedCapacity is", queryreturn['ConsumedCapacity']['CapacityUnits'])


def scan_orders_filterdate(custID, RatingRangeStart, RatingRangeEnd, InputTable):
    region=boto3.session.Session().region_name
    dynamodb = boto3.resource('dynamodb', region_name=region) #low-level Client
    table = dynamodb.Table(InputTable) #define which dynamodb table to access

    recordcount = 0
    recordscannedcount = 0
    capacitycount = 0

    try:
        scanreturn = table.scan(                    # perform first scan
            FilterExpression=Attr("custId").eq(custID) & Attr("orderTs").between(RatingRangeStart, RatingRangeEnd),
            ReturnConsumedCapacity='TOTAL'
        )
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        recordcount += scanreturn['Count']
        recordscannedcount += scanreturn['ScannedCount']
        capacitycount += scanreturn['ConsumedCapacity']['CapacityUnits']
        while 'LastEvaluatedKey' in scanreturn.keys(): # if lastevaluatedkey is present, we need to keep scanning and adding to our counts until everything is scanned
            try:
                scanreturn = table.scan(
                    FilterExpression=Attr("custId").eq(custID) & Attr("orderTs").between(RatingRangeStart, RatingRangeEnd),
                    ExclusiveStartKey = scanreturn['LastEvaluatedKey'],
                    ReturnConsumedCapacity='TOTAL'
                )
            except ClientError as e:
                print(e.response['Error']['Message'])
            else:
                recordcount += scanreturn['Count']
                recordscannedcount += scanreturn['ScannedCount']
                capacitycount += scanreturn['ConsumedCapacity']['CapacityUnits']
        print("Count is ", recordcount)  # print the count of items returned by the scan
        print("ScannedCount is ", recordscannedcount)  # print the count of items that had to be scanned to process the scan
        print("ConsumedCapacity is", capacitycount)



def query_orders_filterdate(custID, RatingRangeStart, RatingRangeEnd, InputTable):
    region=boto3.session.Session().region_name
    dynamodb = boto3.resource('dynamodb', region_name=region) #low-level Client
    table = dynamodb.Table(InputTable) #define which dynamodb table to access

    try:
        queryreturn = table.query(                    # perform first scan
            KeyConditionExpression=Key("custId").eq(custID),
            FilterExpression=Attr("orderTs").between(RatingRangeStart, RatingRangeEnd),
            ScanIndexForward=False,
            ReturnConsumedCapacity='TOTAL'
        )
    except ClientError as e:
        print('Error:  Cannot conduct a query for the customer ', custID)
        print(e.response['Error']['Message'])
    else:
        print("Count is ", queryreturn['Count'])  # print the count of items returned by the query
        print("ScannedCount is ", queryreturn['ScannedCount'])  # print the count of items that had to be scanned to process the query
        print("ConsumedCapacity is", queryreturn['ConsumedCapacity']['CapacityUnits'])


def query_orders_daterange(custID, RatingRangeStart, RatingRangeEnd, LI_name, InputTable):
    region=boto3.session.Session().region_name
    dynamodb = boto3.resource('dynamodb', region_name=region) #low-level Client
    table = dynamodb.Table(InputTable) #define which dynamodb table to access

    try:
        queryreturn = table.query(                    # perform first scan
            IndexName=LI_name,
            KeyConditionExpression=Key("custId").eq(custID) & Key("orderTs").between(RatingRangeStart, RatingRangeEnd),
            ScanIndexForward=False,
            ReturnConsumedCapacity='TOTAL'
        )
    except ClientError as e:
        print('Error:  Cannot conduct a query for the customer ', custID)
        print(e.response['Error']['Message'])
    else:
        print("Count is ", queryreturn['Count'])  # print the count of items returned by the query
        print("ScannedCount is ", queryreturn['ScannedCount'])  # print the count of items that had to be scanned to process the query
        print("ConsumedCapacity is", queryreturn['ConsumedCapacity']['CapacityUnits'])


def query_event(eventID, indextitle, InputTable):
    region=boto3.session.Session().region_name
    dynamodb = boto3.resource('dynamodb', region_name=region) #low-level Client
    table = dynamodb.Table(InputTable) #define which dynamodb table to access

    try:
        queryreturn = table.query(                    # perform first scan
            IndexName=indextitle,            # use index name passed into function call
            KeyConditionExpression=Key("eventSku").eq(eventID) & Key("orderStatus").eq("open"),
            ReturnConsumedCapacity='TOTAL'
        )
    except ClientError as e:
        print('Error:  Cannot conduct a query for the event ', eventID)
        print(e.response['Error']['Message'])
    else:
        print("Count is ", queryreturn['Count'])  # print the count of items returned by the query
        print("ScannedCount is ", queryreturn['ScannedCount'])  # print the count of items that had to be scanned to process the query
        print("ConsumedCapacity is", queryreturn['ConsumedCapacity']['CapacityUnits'])


def scan_event(eventID, InputTable):
    region=boto3.session.Session().region_name
    dynamodb = boto3.resource('dynamodb', region_name=region) #low-level Client
    table = dynamodb.Table(InputTable) #define which dynamodb table to access

    recordcount = 0
    recordscannedcount = 0
    capacitycount = 0

    try:
        scanreturn = table.scan(                    # perform first scan
            FilterExpression=Attr("eventSku").eq(eventID) & Attr("orderStatus").eq("open"),
            ReturnConsumedCapacity='TOTAL'
        )
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        recordcount += scanreturn['Count']
        recordscannedcount += scanreturn['ScannedCount']
        capacitycount += scanreturn['ConsumedCapacity']['CapacityUnits']

        while 'LastEvaluatedKey' in scanreturn.keys(): # if lastevaluatedkey is present, we need to keep scanning and adding to our counts until everything is scanned
            try:
                scanreturn = table.scan(
                    FilterExpression=Attr("eventSku").eq(eventID) & Attr("orderStatus").eq("open"),
                    ExclusiveStartKey = scanreturn['LastEvaluatedKey'],
                    ReturnConsumedCapacity='TOTAL'
                )
            except ClientError as e:
                print(e.response['Error']['Message'])
            else:
                recordcount += scanreturn['Count']
                recordscannedcount += scanreturn['ScannedCount']
                capacitycount += scanreturn['ConsumedCapacity']['CapacityUnits']

        print("Count is ", recordcount)  # print the count of items returned by the query
        print("ScannedCount is ", recordscannedcount)  # print the count of items that had to be scanned to process the query
        print("ConsumedCapacity is", capacitycount)


def main():

    # Verify table and find keys, indexes
    # Upload data
    # Run tests using indexes (or not)

    parser = argparse.ArgumentParser()
    parser.add_argument("tablename", nargs="?", help="The name of the table to be verified i.e. orders1", default='orders')
    args = parser.parse_args()
    TableCheckName = (args.tablename)

    print('')
    print('Verifying table and collecting information from ', TableCheckName)
    yestobase, LSIstr, GSIstr = verify_orders_table(TableCheckName)
    time.sleep(10)
    start = time.time()

    t1 = threading.Thread(target=load_dataset, args=('orders1.json', TableCheckName,))
    t2 = threading.Thread(target=load_dataset, args=('orders2.json', TableCheckName,))
    t3 = threading.Thread(target=load_dataset, args=('orders3.json', TableCheckName,))
    t4 = threading.Thread(target=load_dataset, args=('orders4.json', TableCheckName,))
    t5 = threading.Thread(target=load_dataset, args=('orders5.json', TableCheckName,))

    t1.start()
    print('Loading the data... this may take a minute or two...')
    time.sleep(2)
    t2.start()
    time.sleep(2)
    t3.start()
    time.sleep(2)
    t4.start()
    time.sleep(2)
    t5.start()

    t1.join()
    t2.join()
    t3.join()
    t4.join()
    t5.join()
    
    end = time.time()

    livecount = check_table_load(TableCheckName)
    if (livecount < 74997):
        print('Some items could not be successfully loaded into the orders table.  Review your chosen partition and/or sort keys and try again.')
        quit()

    print('All data successfully loaded')
    print('Total time to load data: {} sec'.format(round(end - start, 3)))

    print('')
    print('Testing access patterns 1 and 2 - adding or udpating a new order for customer \"LL4H5L\"')
    time.sleep(2)
    start = time.time()
    add_order(TableCheckName)
    end = time.time()
    print('Total time for initial PUT of new order: {} sec'.format(round(end - start, 3)))
    print('Test of access patterns 1 and 2 PASSED')
    print('')
    print('-----------------------------------')

    #print('')
    #print('Testing access pattern 3 - retrieving order just created for customer \"LL4H5L\" using a simple scan and filter')
    #time.sleep(2)
    #start = time.time()
    #scan_order(TableCheckName)
    #end = time.time()
    #access3scan = round(end - start, 3)
    #print('Total time for SCAN and filter to fulfill access pattern 3: {} sec'.format(access3scan))
    #print('')
    #print('-----------------------------------')

    if yestobase:
        print('')
        print('Testing access pattern 3 - retrieving order just created for customer \"LL4H5L\" using a get_item call since custID is a key')
        time.sleep(2)
        start = time.time()
        get_order(TableCheckName)
        end = time.time()
        access3query = round(end - start, 3)
        print('Total time for GET of new order: {} sec'.format(access3query))
        print('Test of access pattern 3 PASSED')
        #print('Using custID as a key saved {} seconds for this operation'.format(round((access3scan - access3query), 3)))
        print('')
        print('-----------------------------------')
    else:
        print('Test of access pattern 3 FAILED.  The attribute custID needs to be a key')
        print('')
        print('-----------------------------------')

    #print('')
    #print('Testing access pattern 4 -- retrieving all open orders for event \"DMEL\" using a scan and filter')
    #time.sleep(2)
    #start = time.time()
    #scan_event('DMEL', TableCheckName)
    #end = time.time()
    #access4scan = round(end - start, 3)
    #print('Total time for SCAN of event DMEL: {} sec'.format(access4scan))
    #print('This operation would be more efficient if it used a secondary index that leveraged the attributes eventSku and orderStatus')
    #print('')
    #print('-----------------------------------')


    if (GSIstr != 'Nope'):
        print('')
        print('Testing access pattern 4 -- retrieving all open orders for event \"DMEL\"  using the GSI named {}'.format(GSIstr))
        time.sleep(2)
        start = time.time()
        query_event('DMEL', GSIstr, TableCheckName) 
        end = time.time()
        access4query = round(end - start, 3)
        print('Total time for QUERY of event DMEL: {} sec'.format(access4query))
        print('Test of access pattern 4 PASSED')
        #print('Using a GSI with appropriate keys saved {} seconds for this operation'.format(round((access4scan - access4query), 3)))
        #print('Compare the results of this with the previous operation that did not use a GSI')
        print('')
        print('-----------------------------------')
    else:
        print('Test of access pattern 4 FAILED.  You should use a GSI based on eventSku and orderStatus.')
        print('')
        print('-----------------------------------')



    #print('')
    #print('Testing access pattern 5 -- retrieving customer \"MYTES0\" 10 most recent orders using a simple scan and filter')
    #time.sleep(2)
    #start = time.time()
    #scan_orders_recent_ten('MYTES0', TableCheckName)
    #end = time.time()
    #access5scan = round(end - start, 3)
    #print('Total time for SCAN for first 10 of customer MYTES0: {} sec'.format(access5scan))
    #print('')
    #print('-----------------------------------')


    if yestobase and (LSIstr != 'Nope'):
        print('')
        print('Testing access pattern 5 -- retrieving customer \"MYTES0\" 10 most recent orders using the LSI named {}'.format(LSIstr))
        time.sleep(2)
        start = time.time()
        query_orders_recent_ten_LSI('MYTES0', LSIstr, TableCheckName)
        end = time.time()
        access5queryLSI = round(end - start, 3)
        print('Total time for QUERY for first 10 of customer MYTES0: {} sec'.format(access5queryLSI))
        print('Test of access pattern 5 PASSED')
       # print('Using a LSI with appropriate keys saved {} seconds for this operation'.format(round((access5scan - access5queryLSI), 3)))
        print('')
        print('-----------------------------------')
    else:
        print('Test of access pattern 5 FAILED.  You should use a LSI based on orderTs.')
        print('')
        print('-----------------------------------')


    #print('')
    #print('Testing access pattern 6 -- retrieving orders for customer \"MYTES0\" orders within a given date range using a scan and filter')
    #time.sleep(2)
    #start = time.time()
    #scan_orders_filterdate('MYTES0', Decimal('1647629874.660215'), Decimal('1647629876.4702437'), TableCheckName)
    #end = time.time()
    #access6scan = round(end - start, 3)
    #print('Total time for SCAN with data range of customer MYTES0: {} sec'.format(access6scan))
    #print('This operation would be more efficient if it used a secondary index that leveraged the attribute orderTs')
    #print('')
    #print('-----------------------------------')



    #if yestobase:
    #    print('')
    #    print('Testing access pattern 6 -- retrieving orders for customer \"MYTES0\" orders within a given date range using a query with simple filter')
    #    time.sleep(2)
    #    start = time.time()
    #    query_orders_filterdate('MYTES0', Decimal('1647629874.660215'), Decimal('1647629876.4702437'), TableCheckName)
    #    end = time.time()
    #    access6query = round(end - start, 3)
    #    print('Total time for QUERY with data range of customer MYTES0: {} sec'.format(access6query))
    #    print('Using a query saved {} seconds for this operation'.format(round((access6scan - access6query), 3)))
    #    print('This is better than a plain scan, but the operation would be more efficient if it used a secondary index that leveraged the attribute orderTs')
    #    print('')
    #    print('-----------------------------------')


    if (LSIstr != 'Nope') and yestobase:
        print('')
        print('Testing access pattern 6 -- retrieving orders for customer \"MYTES0\" orders within a given date range using the LSI named {}'.format(LSIstr))
        time.sleep(2)
        start = time.time()
        query_orders_daterange('MYTES0', Decimal('1647629874.660215'), Decimal('1647629876.4702437'), LSIstr, TableCheckName)
        end = time.time()
        access6queryLSI = round(end - start, 3)
        print('Total time for QUERY using LSI with data range of customer MYTES0: {} sec'.format(access6queryLSI))
        print('Test of access pattern 6 PASSED')
        #print('Using a LSI with appropriate keys saved {} seconds for this operation'.format(round((access6scan - access6queryLSI), 3)))
        print('')
        print('-----------------------------------')
    else:
        print('Test of access pattern 6 FAILED.  You should use a LSI based on orderTs.')
        print('')
        print('-----------------------------------')


if __name__ == '__main__':
    main()

